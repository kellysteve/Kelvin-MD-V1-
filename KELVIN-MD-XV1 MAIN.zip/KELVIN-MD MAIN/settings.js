const chalk = require("chalk")
const fs = require("fs")
//auto presence update
global.autoTyping = true //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = true //auto block 212 (true to on, false to off)
global.autokickmorroco = true //auto kick 212 (true to on, false to off) 
global.antispam = false//auto kick spammer (true to on, false to off)
//===============SETTING MENU==================\\
global.thumbnail = fs.readFileSync("./data/image/thumb.jpg")
global.ig = ''
global.yt = ''
global.ttowner = ''
global.ownername = '□□□□□ 0%𝕷𝕺■□□□□ 20%𝕽𝕯■■□□□ 40%𝕹𝕺■■■□□ 60%𝕹𝕬■■■■□ 80%𝕸𝕰■■■■■ 100%' 
global.owner = [''] // SETTINGS ARE ALSO IN THE DATABASE FOLDER 
global.ownernomer = ''
global.socialm = ''
global.location = '' 
//========================setting Payment=====================\\
global.nodana = '' // IT'S BLANK IF IT'S NOT EXISTING
global.nogopay = '' // IT'S BLANK IF IT'S NOT EXISTING 
global.noovo = '' // IT'S BLANK IF IT'S NOT EXISTING
//==================setting Payment Name===========================\\
global.andana = '' // IT'S BLANK IF IT'S NOT EXISTING
global.angopay = '' // IT'S BLANK IF IT'S NOT EXISTING
global.anovo = '' // IT'S BLANK IF IT'S NOT EXISTING
//==================setting bot===========================\\
global.botname = "KELVIN-MD_V1"
global.ownernumber = ''
global.botnumber = ''
global.ownername = 'KELVIN'
global.ownerNumber = [""]
global.ownerweb = "https://whatsapp.com/channel/0029VawEF54Fi8xdbsQ4KL2K"
global.websitex = "https://whatsapp.com/channel/0029VawEF54Fi8xdbsQ4KL2K"
global.wagc = "https://whatsapp.com/channel/0029VawEF54Fi8xdbsQ4KL2K"
global.saluran = "https://whatsapp.com/channel/0029VawEF54Fi8xdbsQ4KL2K"
global.themeemoji = ''
global.wm = ""
global.botscript = '' //script link
global.packname = "ƈɾҽαƚҽԃ Ⴆყ "
global.author = ""
global.creator = ""
global.bankname = ""
global.banknumber = ""
global.bankowner = ""
//======================== CPANEL COMMAND ===========================\\
global.domain = '-' // Fill in your domain, don't put a / at the end of the link
global.apikey = '-' // Fill Apikey
global.capikey = '-' // Fill Apikey
//=========================================================//
//Server create panel egg pm2
global.apikey2 = '-' // Fill Apikey
global.capikey2 = '-' // Fill Apikey
global.domain2 = '-' // Fill Domain
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //don't change it

global.eggsnya2 = '15' // ID of eggs used
global.location2 = '1' // id location
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // ID of eggs used
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
//===========================//

global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '😊',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.prefix = ['','!','.','#','&']
global.sessionName = 'session'
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://i.ibb.co/MPVxV7v/jdw.jpg' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

//messages
global.mess = {
wait: "𝗙𝗜𝗡𝗗𝗜𝗡𝗚.......𝗪𝗔𝗜𝗧 𝗙𝗢𝗥 𝗥𝗘𝗦𝗨𝗟𝗧𝗦 👨‍💻",
   success: "𝐈𝐓 𝐖𝐎𝐑𝐊𝐄𝐃 🤖",
   on: "𝐈'𝐌 𝐀𝐂𝐓𝐈𝐕𝐄 🤖", 
   off: "𝐈'𝐌 𝐎𝐅𝐅 ⚠️",
   query: {
       text: "𝐖𝐇𝐄𝐑𝐄 𝐈𝐒 𝐓𝐇𝐄 𝐓𝐄𝐗𝐓? ⚠️",
       link: "𝐖𝐇𝐄𝐑𝐄 𝐈𝐒 𝐓𝐇𝐄 𝐋𝐈𝐍𝐊? ⚠️",
   },
   error: {
       fitur: "𝐒𝐎𝐑𝐑𝐘 𝐓𝐇𝐄 𝐅𝐄𝐀𝐓𝐔𝐑𝐄 𝐇𝐀𝐒 𝐄𝐑𝐑𝐎𝐑, 𝐊𝐈𝐍𝐃𝐋𝐘 𝐂𝐎𝐍𝐓𝐀𝐂𝐓 𝐓𝐇𝐄 𝐎𝐖𝐍𝐄𝐑 𝐓𝐎 𝐅𝐈𝐗 𝐈𝐓 ⚠️",
   },
   only: {
       group: "𝐂𝐎𝐌𝐌𝐀𝐍𝐃 𝐂𝐀𝐍 𝐎𝐍𝐋𝐘 𝐁𝐄 𝐔𝐒𝐄𝐃 𝐈𝐍 𝐆𝐑𝐎𝐔𝐏𝐒 ⚠️",
       private: "𝐈𝐓𝐒 𝐎𝐍𝐋𝐘 𝐅𝐎𝐑 𝐏𝐑𝐈𝐕𝐀𝐓𝐄 𝐂𝐇𝐀𝐓𝐒 ⚠️",
       owner: "𝐈𝐓 𝐂𝐀𝐍 𝐎𝐍𝐋𝐘 𝐁𝐄 𝐔𝐒𝐄𝐃 𝐁𝐘 𝐓𝐇𝐄 𝐎𝐖𝐍𝐄𝐑 ⚠️",
       admin: "𝐈 𝐀𝐌 𝐍𝐎𝐓 𝐀𝐍 𝐀𝐃𝐌𝐈𝐍 ⚠️",
       badmin: "𝐌𝐀𝐊𝐄 𝐌𝐄 𝐀𝐍 𝐀𝐃𝐌𝐈𝐍 ⚠️",
       premium: "𝐓𝐇𝐈𝐒 𝐂𝐎𝐌𝐌𝐀𝐍𝐃 𝐈𝐒 𝐅𝐎𝐑 𝐌𝐘 𝐎𝐖𝐍𝐄𝐑 𝐎𝐍𝐋𝐘 ⚠️",
   }
}
 
//if api key expire, u can generate one from here: https://beta.openai.com/account/api-keys
global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
